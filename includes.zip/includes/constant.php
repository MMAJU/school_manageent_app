<?php 
	define( "DB_DSN", "mysql:dbname=tracking" );
	define("DB_USERNAME", "rico");
	define("DB_PASSWORD", "nightg007");
	//$item_per_page = 10;
	//define("DB_NAME", "ehr_db");
?>